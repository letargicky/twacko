-made by luxinferni on dc
language: c#
requirements: run as administrator